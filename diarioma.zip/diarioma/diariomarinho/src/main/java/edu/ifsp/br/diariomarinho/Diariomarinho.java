package edu.ifsp.br.diariomarinho;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Diariomarinho {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        ArrayList<Visitante> visitantes = new ArrayList<>();

        carregarVisitantes(visitantes);

        int opcao;

        do {
            System.out.println("\n--- Diario Marinho ---");
            System.out.println("1 - Cadastrar novo visitante");
            System.out.println("2 - Listar visitantes");
            System.out.println("0 - Sair");
            System.out.print("Escolha uma opcao: ");

            while (!teclado.hasNextInt()) { 
                System.out.print("Opção invalida! Digite novamente: ");
                teclado.next();
            }
            opcao = teclado.nextInt();
            teclado.nextLine();

            switch (opcao) {
                case 1:
                    System.out.print("Nome do visitante: ");
                    String nome = teclado.nextLine();

                    System.out.print("Idade do visitante: ");
                    while (!teclado.hasNextInt()) {
                        System.out.print("Valor invalido! Digite a idade novamente: ");
                        teclado.next();
                    }
                    int idade = teclado.nextInt();
                    teclado.nextLine();

                    System.out.print("Escola do visitante: ");
                    String escola = teclado.nextLine();

                    boolean participouDeTodosProjetos;
                    while (true) {
                        System.out.print("Participou de todos os projetos? (Sim/Nao): ");
                        String resposta = teclado.nextLine().trim().toLowerCase();
                        if (resposta.equals("sim")) {
                            participouDeTodosProjetos = true;
                            break;
                        } else if (resposta.equals("não") || resposta.equals("nao")) {
                            participouDeTodosProjetos = false;
                            break;
                        } else {
                            System.out.println("Resposta invalida! Digite 'Sim' ou 'Nao'.");
                        }
                    }

                    System.out.print("Feedback (0-10): ");
                    while (!teclado.hasNextInt()) {
                        System.out.print("Valor invalido! Digite um número: ");
                        teclado.next();
                    }
                    int feedback = teclado.nextInt();
                    teclado.nextLine();

                    Visitante novoVisitante = new Visitante(nome, idade);
                    novoVisitante.setEscola(escola);
                    novoVisitante.setParticipouDeTodosProjetos(participouDeTodosProjetos);
                    novoVisitante.setFeedback(feedback);

                    visitantes.add(novoVisitante);

                    System.out.println("✅ Visitante cadastrado com sucesso!");
                    break;

                case 2:
                    System.out.println("\n--- Visitantes cadastrados ---");
                    if (visitantes.isEmpty()) {
                        System.out.println("Nenhum visitante cadastrado ainda.");
                    } else {
                        for (int i = 0; i < visitantes.size(); i++) {
                            System.out.println((i + 1) + ". " + visitantes.get(i));
                        }
                    }
                    break;

                case 0:
                    salvarVisitantes(visitantes);
                    System.out.println("Encerrando o programa. Até logo!");
                    break;

                default:
                    System.out.println("Opção invalida!");
                    break;
            }

        } while (opcao != 0);

        teclado.close();
    }

    private static void salvarVisitantes(ArrayList<Visitante> visitantes) {
        try (FileWriter writer = new FileWriter("visitantes.txt")) {
            for (Visitante v : visitantes) {
                String participouTexto = v.isParticipouDeTodosProjetos() ? "Sim" : "Nao";

                String feedbackTexto = (v.getFeedback() == -1)
                        ? "Nota nao informada"
                        : "Nota " + v.getFeedback();

                writer.write(
                    v.getNome() + ";" +
                    v.getIdade() + ";" +
                    v.getEscola() + ";" +
                    participouTexto + ";" +
                    feedbackTexto + "\n"
                );
            }
            System.out.println("✅ Visitantes salvos no arquivo visitantes.txt");
        } catch (IOException e) {
            System.out.println("⚠️ Erro ao salvar os visitantes: " + e.getMessage());
        }
    }

    private static void carregarVisitantes(ArrayList<Visitante> visitantes) {
        try (BufferedReader reader = new BufferedReader(new FileReader("visitantes.txt"))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                String[] partes = linha.split(";");
                if (partes.length == 5) {
                    String nome = partes[0];
                    int idade = Integer.parseInt(partes[1]);
                    String escola = partes[2];

                    boolean participou = partes[3].equalsIgnoreCase("Sim");

                    int feedback;
                    if (partes[4].equalsIgnoreCase("Nota não informada")) {
                        feedback = -1;
                    } else if (partes[4].toLowerCase().startsWith("nota ")) {
                        feedback = Integer.parseInt(partes[4].substring(5));
                    } else {
                        feedback = -1;
                    }

                    Visitante v = new Visitante(nome, idade);
                    v.setEscola(escola);
                    v.setParticipouDeTodosProjetos(participou);
                    v.setFeedback(feedback);

                    visitantes.add(v);
                }
            }
            System.out.println("📂 Visitantes carregados do arquivo.");
        } catch (IOException e) {
            System.out.println("⚠️ Nenhum arquivo encontrado, iniciando lista vazia.");
        }
    }
}
