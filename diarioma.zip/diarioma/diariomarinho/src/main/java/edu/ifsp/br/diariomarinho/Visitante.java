package edu.ifsp.br.diariomarinho;

public class Visitante {
    private String nome;
    private int idade;
    private String escola;
    private boolean participouDeTodosProjetos;
    private int feedback;

    public Visitante(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
        this.escola = "Não informado";
        this.participouDeTodosProjetos = false;
        this.feedback = -1; 
    }

    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }

    public String getEscola() {
        return escola;
    }

    public void setEscola(String escola) {
        this.escola = escola;
    }

    public boolean isParticipouDeTodosProjetos() {
        return participouDeTodosProjetos;
    }

    public void setParticipouDeTodosProjetos(boolean participou) {
        this.participouDeTodosProjetos = participou;
    }

    public int getFeedback() {
        return feedback;
    }

    public void setFeedback(int feedback) {
        this.feedback = feedback;
    }

    @Override
    public String toString() {
        return "Nome: " + nome +
               ", Idade: " + idade +
               ", Escola: " + escola +
               ", Participou de todos os projetos: " + (participouDeTodosProjetos ? "Sim" : "Nao") +
               ", Feedback: " + (feedback == -1 ? "Não informado" : feedback + "/10");
    }
}
